class CategoryWarning(UserWarning):pass
