from .main_click import main
import sys
if __name__=='__main__':
    sys.exit(main())
