vowels='aeiouy'
consonants='bcdfghjklmnpqrstvwxz'
